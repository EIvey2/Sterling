import { StyleSheet, Text, View, Image, TextInput } from "react-native";
import Button from '@/components/Button';
import { useState } from 'react';


export default function Index() {

  const[enterQuestion, setQuestion] =  useState('');
  const[answer, setAnswer] = useState('');
  

  const responses = [
    'Yes, definitely!',
    'Ask again later.',
    'Cannot predict now.',
    'No, try something else.',
    'Absolutely!',
    'Don’t count on it.',
    'Very likely.',
    'My sources say no.',
  ];
  const handleSubmit = () => {
    if (enterQuestion.trim() === '') return;
    const randomIndex = Math.floor(Math.random() * responses.length);
    setAnswer(responses[randomIndex]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Magic 8 Ball</Text>
      <TextInput
        style={styles.input}
        placeholder="Ask a yes or no question"
        value={enterQuestion}
        onChangeText={setQuestion}
      />
      <Button label="Submit" onPress={handleSubmit} />

      {/* Display the question and answer directly on the screen */}
      {answer && (
        <View style={styles.resultContainer}>
          <Text style={styles.enterQuestionText}>Your Question: {enterQuestion}</Text>
          <Text style={styles.answerText}>Answer: {answer}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#333',
    padding: 20,
    color: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#fff',
  },
  input: {
    width: '100%',
    padding: 10,
    borderWidth: 1,
    borderColor: '#fff',
    borderRadius: 8,
    marginBottom: 20,
    color: '#fff',
  },
  resultContainer: {
    marginTop: 20,
    alignItems: 'center',
    color: '#fff',
  },
  enterQuestionText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#fff',
  },
  answerText: {
    fontSize: 16,
    marginTop: 10,
    fontStyle: 'italic',
    color: '#fff',
  },
  placeholder: {
    marginTop: 20,
    alignItems: 'center',
    color: '#fff',
  }
});