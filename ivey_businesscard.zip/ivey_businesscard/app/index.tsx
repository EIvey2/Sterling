import { ThemedText } from "@/components/ThemedText";
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedView } from '@/components/ThemedView';
import { Linking, Image, TouchableOpacity, StyleSheet } from "react-native";

export default function Index() {
  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}
      headerImage={
        <Image
          source={require('@/assets/images/myimage.jpeg')}
          style={styles.myimage}
        />
      }>
    <ThemedView
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
      }}
      
    >
      <ThemedText type="subtitle">Name: Emily Ivey</ThemedText>
      <ThemedText>Email: </ThemedText>
        <TouchableOpacity onPress={() => Linking.openURL('mailto:eivey2@hgtc.edu')}>
          <ThemedText type="defaultSemiBold">eivey2@hgtc.edu</ThemedText>
        </TouchableOpacity>

        <ThemedText>Phone: </ThemedText>
        <TouchableOpacity onPress={() => Linking.openURL('tel:+18437588219')}>
          <ThemedText type="defaultSemiBold">+1 (843) 758-8219</ThemedText>
        </TouchableOpacity>

        <ThemedText>GitHub: </ThemedText>
        <TouchableOpacity onPress={() => Linking.openURL('https://github.com/EIvey2/Sterling')}>
          <ThemedText type="defaultSemiBold">emilyivey</ThemedText>
        </TouchableOpacity>
        
      </ThemedView>
      </ParallaxScrollView>
  );
}
  const styles = StyleSheet.create({
    titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 20,
  },
  myimage: {
    height: 100,
    width: 100,
    borderRadius: 50,
    marginBottom: 20,
  },
});

