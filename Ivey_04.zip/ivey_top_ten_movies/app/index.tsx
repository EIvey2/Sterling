import { Text, View, Image, FlatList, StyleSheet, ImageSourcePropType } from "react-native";

interface OurItem {
  id: string;
  movieName: string;
  otherInfo: string;
  poster: ImageSourcePropType; 
}

const DATA: OurItem[] = [
  { id: '1', movieName: 'The Dark Knight', poster: require('@/assets/moviePosters/dark_knight.jpg'), otherInfo: 'Rating: 9.0' },
  { id: '2', movieName: 'Burlesque', poster: require('@/assets/moviePosters/burlesque.jpg'), otherInfo: 'Rating: 6.5' },
  { id: '3', movieName: 'Alice in Wonderland', poster: require('@/assets/moviePosters/Alice_in_Wonderland.png'), otherInfo: 'Rating: 6.4' },
  { id: '4', movieName: 'Twilight', poster: require('@/assets/moviePosters/twilight.jpg'), otherInfo: 'Rating: 5.2' },
  { id: '5', movieName: 'Beauty and the Beast', poster: require('@/assets/moviePosters/beauty_and_the_beast.jpg'), otherInfo: 'Rating: 8.0' },
  { id: '6', movieName: 'Elf', poster: require('@/assets/moviePosters/elf.jpg'), otherInfo: 'Rating: 7.0' },
  { id: '7', movieName: 'Avengers: Endgame', poster: require('@/assets/moviePosters/avengers_endgame.jpg'), otherInfo: 'Rating: 8.4' },
  { id: '8', movieName: 'Harry Potter', poster: require('@/assets/moviePosters/harry_potter.jpg'), otherInfo: 'Rating: 7.9' },
  { id: '9', movieName: 'Spider-Man', poster: require('@/assets/moviePosters/spiderman.jpg'), otherInfo: 'Rating: 7.3' },
  { id: '10', movieName: 'Titanic', poster: require('@/assets/moviePosters/titanic.jpg'), otherInfo: 'Rating: 7.8' }
];

const ItemComponent = ({ item }: { item: OurItem }) => (
  <View style={styles.item}>
    <Text>{item.movieName}</Text>
    <Image style={{ height: 80, width: 50 }} source={item.poster} />
    <Text>{item.otherInfo}</Text>
  </View>
);

export default function Index() {
  return (
    <View style={{ flex: 1 }}>
      <Text style={styles.header}>My Top 10 Movies</Text>
      <FlatList
        data={DATA}
        renderItem={({ item }) => <ItemComponent item={item} />}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#AFDCEC',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
});
